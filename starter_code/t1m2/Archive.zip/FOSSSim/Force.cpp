#include "Force.h"

Force::~Force()
{}
