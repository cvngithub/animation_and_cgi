#include "SymplecticEuler.h"

bool SymplecticEuler::stepScene( TwoDScene& scene, scalar dt )
{
  /* Add milestone 2 code here.      */
  
  return true;
}






