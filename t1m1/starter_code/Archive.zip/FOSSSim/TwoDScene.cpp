#include "TwoDScene.h"

scalar TwoDScene::computeKineticEnergy() const
{
    return -1.0;
}
